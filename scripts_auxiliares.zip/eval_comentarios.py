import os
import numpy as np
from gensim.models import KeyedVectors
from sklearn.metrics.pairwise import cosine_similarity
import pandas as pd
from collections import defaultdict
import logging

def compare_models(pretrained_path, verbose=True):
    models = {}
    results = {'pretrained': {}}
    for model_type, path in [('pretrained', pretrained_path)]:
        if not os.path.exists(path):
            return None
        try:
            models[model_type] = KeyedVectors.load(path)
            results[model_type]['model_loaded'] = True
        except Exception as e:
            return None
    for model_type, model in models.items():
        results[model_type]['vocab_size'] = len(model.index_to_key)
        results[model_type]['vector_size'] = model.vector_size
        if results[model_type]['vocab_size'] < 1000:
            pass
    for model_type, model in models.items():
        norms = np.linalg.norm(model.vectors, axis=1)
        results[model_type]['mean_norm'] = float(np.mean(norms))
        results[model_type]['norm_std'] = float(np.std(norms))
    semantic_pairs = [('homem', 'mulher'), ('bom', 'ruim'), ('feliz', 'triste'), ('grande', 'pequeno'), ('dia', 'noite'), ('amor', 'ódio'), ('rico', 'pobre'), ('velho', 'novo'), ('forte', 'fraco'), ('alto', 'baixo')]
    for model_type in models:
        results[model_type]['similarity_scores'] = []
    for word1, word2 in semantic_pairs:
        for model_type, model in models.items():
            try:
                sim = model.similarity(word1, word2)
                results[model_type]['similarity_scores'].append(sim)
            except KeyError:
                pass
    analogy_pairs = [('presidente', 'brasil', 'prefeito', 'são_paulo'), ('congresso', 'lei', 'tribunal', 'decisão'), ('economia', 'imposto', 'trabalho', 'salário'), ('educação', 'escola', 'saúde', 'hospital'), ('brasil', 'brasília', 'frança', 'paris')]
    for model_type in models:
        results[model_type]['analogy_scores'] = []
        for a, b, c, expected in analogy_pairs:
            try:
                result = models[model_type].most_similar(positive=[b, c], negative=[a], topn=1)
                predicted = result[0][0]
                score = models[model_type].similarity(predicted, expected)
                results[model_type]['analogy_scores'].append(score)
            except KeyError:
                pass
    test_words = ['brasil', 'política', 'dinheiro', 'trabalho', 'vida', 'amor', 'tempo', 'pessoa']
    for model_type in models:
        results[model_type]['neighborhood_scores'] = []
        for word in test_words:
            try:
                neighbors = models[model_type].most_similar(word, topn=5)
                for neighbor, score in neighbors:
                    pass
                neighbor_words = [n[0] for n in neighbors]
                coherence = calculate_neighborhood_coherence(models[model_type], neighbor_words)
                results[model_type]['neighborhood_scores'].append(coherence)
            except KeyError:
                pass
    analogy_pairs = [('presidente', 'brasília', 'governador', None), ('prefeito', 'município', 'governador', None), ('presidente', 'decreto', 'congresso', None), ('governo', 'política', 'oposição', None), ('liderança', 'autoridade', 'representação', None), ('senado', 'legislação', 'supremo', None), ('câmara', 'deputado', 'senado', None), ('congresso', 'lei', 'tribunal', None), ('impeachment', 'congresso', 'cassação', None), ('constituição', 'direitos', 'regulamentos', None), ('economia', 'imposto', 'trabalho', None), ('crescimento', 'investimento', 'inflação', None), ('desemprego', 'trabalho', 'pobreza', None), ('reforma', 'tributária', 'reforma', None), ('agropecuária', 'exportação', 'indústria', None), ('educação', 'professor', 'saúde', None), ('universidade', 'ensino', 'hospital', None), ('segurança', 'polícia', 'educação', None), ('cultura', 'incentivo', 'tecnologia', None), ('moradia', 'direito', 'pobreza', None), ('democracia', 'eleição', 'ditadura', None), ('liberdade', 'direitos', 'controle', None), ('progresso', 'crescimento', 'conservadorismo', None), ('populismo', 'discursos', 'liberalismo', None), ('corrupção', 'ética', 'impunidade', None), ('brasil', 'brasília', 'argentina', None), ('mercosul', 'acordo', 'onu', None), ('exportação', 'comércio', 'importação', None), ('diplomacia', 'negociação', 'sanção', None), ('américa', 'latina', 'europa', None), ('manifestação', 'protesto', 'negociação', None), ('voto', 'eleitor', 'proposta', None), ('campanha', 'promessa', 'governo', None), ('comunicação', 'discurso', 'ação', None), ('redes', 'sociais', 'imprensa', None), ('pobreza', 'desigualdade', 'riqueza', None), ('trabalho', 'direitos', 'mercado', None), ('meio_ambiente', 'preservação', 'desmatamento', None), ('energia', 'sustentável', 'petróleo', None), ('segurança', 'crime', 'educação', None)]
    for x, y, z, _ in analogy_pairs:
        output_line = f'{x} is to {y}, as {z} is to: '
        predictions = []
        for model_type, model in models.items():
            try:
                predicted = model.most_similar(positive=[y, z], negative=[x], topn=1)[0][0]
                predictions.append(f'{predicted}')
            except KeyError:
                continue
        if predictions:
            output_line += ', '.join(predictions)
    domain_keywords = {'Sentimentos': ['feliz', 'triste', 'raiva', 'alegria', 'medo'], 'Política': ['governo', 'presidente', 'política', 'congresso', 'votação'], 'Social': ['povo', 'sociedade', 'comunidade', 'família', 'grupo'], 'Avaliação': ['bom', 'ruim', 'ótimo', 'péssimo', 'melhor'], 'Tópicos': ['brasil', 'educação', 'saúde', 'economia', 'segurança'], 'Ações': ['fazer', 'mudar', 'criar', 'desenvolver', 'construir'], 'Problemas': ['crise', 'problema', 'dificuldade', 'corrupção', 'violência']}
    for model_type, model in models.items():
        for category, words in domain_keywords.items():
            for word in words:
                try:
                    neighbors = model.most_similar(word, topn=7)
                    avg_sim = sum((score for _, score in neighbors)) / len(neighbors)
                    for neighbor, score in neighbors:
                        marker = ''
                        if score > 0.8:
                            marker = '🟢'
                        elif score < 0.3:
                            marker = '🔴'
                except KeyError:
                    pass
    for model_type in models:
        total_found = 0
        total_words = 0
        high_similarity_count = 0
        low_similarity_count = 0
        for category, words in domain_keywords.items():
            for word in words:
                total_words += 1
                try:
                    neighbors = models[model_type].most_similar(word, topn=7)
                    total_found += 1
                    for _, score in neighbors:
                        if score > 0.8:
                            high_similarity_count += 1
                        elif score < 0.3:
                            low_similarity_count += 1
                except KeyError:
                    continue
        coverage = total_found / total_words * 100
    for model_type in models:
        scores = {'Vocabulary Size': min(1.0, results[model_type]['vocab_size'] / 10000), 'Vector Quality': 1.0 - abs(results[model_type]['mean_norm'] - 1.0), 'Semantic Relations': np.mean(results[model_type]['similarity_scores']) if results[model_type]['similarity_scores'] else 0, 'Analogy Performance': np.mean(results[model_type]['analogy_scores']) if results[model_type]['analogy_scores'] else 0, 'Neighborhood Coherence': np.mean(results[model_type]['neighborhood_scores']) if results[model_type]['neighborhood_scores'] else 0}
        for metric, score in scores.items():
            pass
        overall_score = np.mean(list(scores.values()))
        results[model_type]['overall_score'] = overall_score
    df = pd.DataFrame({'Metric': ['Overall Score', 'Vocab Size', 'Vector Size', 'Mean Norm', 'Semantic Score', 'Analogy Score', 'Neighborhood Score'], 'Pretrained': [results['pretrained']['overall_score'], results['pretrained']['vocab_size'], results['pretrained']['vector_size'], results['pretrained']['mean_norm'], np.mean(results['pretrained']['similarity_scores']) if results['pretrained']['similarity_scores'] else 0, np.mean(results['pretrained']['analogy_scores']) if results['pretrained']['analogy_scores'] else 0, np.mean(results['pretrained']['neighborhood_scores']) if results['pretrained']['neighborhood_scores'] else 0]})
    df.to_csv('model_comparison_results.csv', index=False)
    return results

def calculate_neighborhood_coherence(model, words):
    if len(words) < 2:
        return 0.0
    vectors = np.array([model[word] for word in words])
    similarities = cosine_similarity(vectors)
    np.fill_diagonal(similarities, 0)
    return float(np.mean(similarities))
if __name__ == '__main__':
    pretrained_path = 'models/comentarios.model'
    results = compare_models(pretrained_path)
