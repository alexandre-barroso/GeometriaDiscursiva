import praw
import random
reddit = praw.Reddit(client_id='INSERIR_AQUI', client_secret='INSERIR_AQUI', user_agent='INSERIR_AQUI')

def crawl_subreddit(subreddit_name, num_threads=1000):
    subreddit = reddit.subreddit(subreddit_name)
    all_threads = list(subreddit.hot(limit=1000))
    selected_threads = random.sample(all_threads, min(num_threads, len(all_threads)))
    total_comments = 0
    title_file_name = f'titulos_threads_{subreddit_name}.txt'
    comments_file_name = f'comentarios_{subreddit_name}.txt'
    with open(title_file_name, 'w', encoding='utf-8') as title_file, open(comments_file_name, 'w', encoding='utf-8') as comments_file:
        for thread in selected_threads:
            title_file.write(f'{thread.title} - Comments saved: ')
            thread.comments.replace_more(limit=0)
            comments = thread.comments.list()
            for comment in comments:
                comments_file.write(comment.body + '\n')
            num_comments = len(comments)
            total_comments += num_comments
            title_file.write(f'{num_comments}\n')
        title_file.write(f'\nTotal Comments: {total_comments}\n')
subreddits = ['investimentos']
num_threads_per_subreddit = 1000
for subreddit_name in subreddits:
    crawl_subreddit(subreddit_name, num_threads=num_threads_per_subreddit)
