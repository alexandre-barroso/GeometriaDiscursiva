import re

def clean_text(text):
    text = re.sub('http\\S+|www\\S+|https\\S+', '', text, flags=re.MULTILINE)
    text = re.sub('[^\\w\\sáàâãéèêíïóôõöúçñÁÀÂÃÉÈÊÍÏÓÔÕÖÚÇÑ.,!?]', '', text)
    text = re.sub('\\d+', '', text)
    text = text.lower()
    text = re.sub('\\s+', ' ', text).strip()
    return text
files_to_clean = ['comentarios_brasil.txt', 'comentarios_BrasildoB.txt', 'comentarios_brasilivre.txt', 'comentarios_conversas.txt', 'comentarios_saopaulo.txt', 'comentarios_desabafos.txt', 'comentarios_investimentos.txt']
for file_name in files_to_clean:
    with open(file_name, 'r', encoding='utf-8') as file:
        content = file.read()
    cleaned_content = clean_text(content)
    cleaned_file_name = file_name.replace('.txt', '_limpo.txt')
    with open(cleaned_file_name, 'w', encoding='utf-8') as cleaned_file:
        cleaned_file.write(cleaned_content)
