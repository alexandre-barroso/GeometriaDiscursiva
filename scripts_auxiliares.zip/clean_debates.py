import re

def clean_text(text):
    text = re.sub('Chunk\\s+\\d+\\s+\\[\\d+\\.\\d+s-\\d+\\.\\d+s\\]:', '', text, flags=re.MULTILINE)
    text = re.sub('http\\S+|www\\S+|https\\S+', '', text, flags=re.MULTILINE)
    text = re.sub('[^\\w\\sáàâãéèêíïóôõöúçñÁÀÂÃÉÈÊÍÏÓÔÕÖÚÇÑ.,!?]', '', text)
    text = re.sub('\\d+', '', text)
    text = text.lower()
    text = re.sub('\\s+', ' ', text).strip()
    return text
files_to_clean = ['debates_todos.txt']
for file_name in files_to_clean:
    with open(file_name, 'r', encoding='utf-8') as file:
        content = file.read()
    cleaned_content = clean_text(content)
    cleaned_file_name = file_name.replace('debates_todos.txt', 'corpus_debates.txt')
    with open(cleaned_file_name, 'w', encoding='utf-8') as cleaned_file:
        cleaned_file.write(cleaned_content)
