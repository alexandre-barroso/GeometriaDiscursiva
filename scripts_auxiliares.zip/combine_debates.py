cleaned_files = ['transcricao_1.txt', 'DEBATE_UOL.txt', 'DEBATE_TERRA.txt', 'DEBATE_RECORD2.txt']
output_file = 'debates_todos.txt'
with open(output_file, 'w', encoding='utf-8') as corpus_file:
    for file_name in cleaned_files:
        with open(file_name, 'r', encoding='utf-8') as cleaned_file:
            content = cleaned_file.read()
            corpus_file.write(content + '\n')
