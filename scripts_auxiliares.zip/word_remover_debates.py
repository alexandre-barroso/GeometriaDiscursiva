import os
import re

def remove_words_from_file(file_path, words_to_remove):
    if not os.path.exists(file_path):
        raise FileNotFoundError(f'The file {file_path} does not exist.')
    pattern = '\\b(' + '|'.join((re.escape(word) for word in words_to_remove)) + ')\\b'
    with open(file_path, 'r', encoding='utf-8') as file:
        content = file.read()
    modified_content = re.sub(pattern, '', content)
    with open(file_path, 'w', encoding='utf-8') as file:
        file.write(modified_content)

def replace_words_in_file(file_path, replacements):
    if not os.path.exists(file_path):
        raise FileNotFoundError(f'The file {file_path} does not exist.')
    pattern = '\\b(' + '|'.join((re.escape(word) for word in replacements.keys())) + ')\\b'

    def replacement_func(match):
        return replacements[match.group(0)]
    with open(file_path, 'r', encoding='utf-8') as file:
        content = file.read()
    modified_content = re.sub(pattern, replacement_func, content)
    with open(file_path, 'w', encoding='utf-8') as file:
        file.write(modified_content)
if __name__ == '__main__':
    file_path = 'corpus_debates.txt'
    words_to_remove = ['aeno', 'r7.com', 'estadão.com', 'imboe', 'r7', 'r.com']
    replacements = {'são paulo': 'são_paulo', 'rio de janeiro': 'rio_de_janeiro'}
    try:
        remove_words_from_file(file_path, words_to_remove)
        replace_words_in_file(file_path, replacements)
    except Exception as e:
        pass
