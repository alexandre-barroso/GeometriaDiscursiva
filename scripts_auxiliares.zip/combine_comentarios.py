cleaned_files = ['comentarios_brasil_limpo.txt', 'comentarios_BrasildoB_limpo.txt', 'comentarios_brasilivre_limpo.txt', 'comentarios_conversas_limpo.txt', 'comentarios_saopaulo_limpo.txt', 'comentarios_desabafos_limpo.txt', 'comentarios_investimentos_limpo.txt']
output_file = 'corpus.txt'
with open(output_file, 'w', encoding='utf-8') as corpus_file:
    for file_name in cleaned_files:
        with open(file_name, 'r', encoding='utf-8') as cleaned_file:
            content = cleaned_file.read()
            corpus_file.write(content + '\n')
