import whisper
from pydub import AudioSegment

def transcribe_audio_incrementally(audio_path, output_file, chunk_duration_ms=60000, language='pt'):
    model = whisper.load_model('medium')
    audio = AudioSegment.from_file(audio_path)
    total_duration = len(audio)
    with open(output_file, 'w', encoding='utf-8') as file:
        chunk_count = total_duration // chunk_duration_ms + 1
        for i in range(chunk_count):
            start = i * chunk_duration_ms
            end = min((i + 1) * chunk_duration_ms, total_duration)
            chunk = audio[start:end]
            chunk.export('temp_chunk.wav', format='wav')
            result = model.transcribe('temp_chunk.wav', language=language)
            text = result.get('text', '')
            file.write(f'Chunk {i + 1} [{start / 1000:.2f}s-{end / 1000:.2f}s]:\n{text}\n\n')
if __name__ == '__main__':
    audio_file = 'DEBATES_pt2.mp3'
    output_file = 'transcription_pt2.txt'
    transcribe_audio_incrementally(audio_file, output_file, chunk_duration_ms=60000, language='pt')
