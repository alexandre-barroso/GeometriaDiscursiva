import re

def count_total_comments_from_thread_file(thread_file):
    total_comments = 0
    try:
        with open(thread_file, 'r', encoding='utf-8') as file:
            for line in file:
                match = re.search('Comments saved: (\\d+)', line)
                if match:
                    total_comments += int(match.group(1))
    except FileNotFoundError:
        return 0
    except Exception as e:
        return 0
    return total_comments
subreddit = 'desabafos'
thread_file = f'titulos_threads_{subreddit}.txt'
total_comments = count_total_comments_from_thread_file(thread_file)
